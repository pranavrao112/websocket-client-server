const express = require("express");
const app = express();
const server = require('http').createServer(app);
const WebSocket = require('ws');

const wss = new WebSocket.Server({ server: server });

const waitFunction = require('./common/delay');

const fs = require('fs');

wss.on('connection', function connection(ws) {
  ws.on('message', async function message(data) {
    ws.isAlive = true;
    try {
      console.log('Incoming data :', JSON.parse(data));
      const message = JSON.parse(data);
      let getCount, count, latestCount, response;
      if (message.type === `Subscribe`) {
            /* wait for 4 second */
            await waitFunction.delay(4000);
             response = {
              type: `Subscribe`,
              status: `Subscribed`,
              updatedAt: new Date()
            };
            console.log(response);
            /* Write output to a file, from this file we will read and 
                fetch the count at later point */

            /* When the file is empty, or first write */
            if(fs.readFileSync(`./result/Output.txt`).length === 0){
               fs.writeFileSync(`./result/Output.txt`, JSON.stringify({
                 noOfSubscribers: 1
               }));
            }else {

              /* Increase the count by 1 */
               getCount = fs.readFileSync(`./result/Output.txt`);
               count = JSON.parse(getCount);
               latestCount = {
                noOfSubscribers : count.noOfSubscribers+1
              };
             fs.writeFileSync(`./result/Output.txt`, JSON.stringify(latestCount));  
            }                 
            return response;
      } else if (message.type === `Unsubscribe`) {
            /* Wait for 8 second */
            await waitFunction.delay(8000);
             response = {
              type: `Unscubscribe`,
              status: `Unsubscribed`,
              updatedAt: new Date()
            };
            console.log(response);
            /* Reduce the count of subscribers by 1 */
             getCount = fs.readFileSync(`./result/Output.txt`);
             count = JSON.parse(getCount);
             latestCount = {
              noOfSubscribers : count.noOfSubscribers-1
            };
           fs.writeFileSync(`./result/Output.txt`, JSON.stringify(latestCount));  

            return response;
      } else if (message.type === `CountSubscribers`) {
            /* Count the subscribers by processing the file */
            const resp = fs.readFileSync(`./result/Output.txt`);
            console.log('No of active subscribers :', JSON.parse(resp));
            return resp;
      } else if (message.type === `HeartBeat`) {
        for(const i=0;i<Infinity;i++){
          ws.on("pong", () => { ws.isAlive = true; });
          await waitFunction.delay(1000);
        }
      } else {
        response = {
            type : 'Error',
            error : 'Requested method not implemented',
            updatedAt: new Date()
          };
          console.log('Response :', response);
          return response;
      }
    } catch (e) {
      const errResponse = {
        type : 'Error',
        error : 'Bad formatted payload, non JSON',
        updatedAt : new Date()
      };
      console.log('Message not in an expected format : ', errResponse);
      console.log('Exception :'. e.message);
      return errResponse;

    }
  });

});

server.listen(3000, () => console.log(`Server listening to port : ${process.env.port || 3000}`))

