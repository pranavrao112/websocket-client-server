Install dependencies 

1. npm install 

Running the app

2. node index.js

-----------------------------------------------------------------------------------------------

Use the file /socket/clientsubscribe.html as a client ( say UI ) 
We can modify the above file for different types : Subscribe | Unsubscribe | CountSubscribers

-----------------------------------------------------------------------------------------------

